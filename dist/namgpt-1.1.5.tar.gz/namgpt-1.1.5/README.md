<p align="center">
  <img src="assets/banner.png">
</p>

<h1 align="center">🤖 NamGPT</h1>

<p align="center">
A beautiful command-line interface built with
<b>Typer</b> • <b>Rich</b> • <b>Questionary</b>
</p>
<p align="center">

![Python](https://img.shields.io/badge/Python-3.10+-blue)

![License](https://img.shields.io/badge/License-MIT-green)

![CLI](https://img.shields.io/badge/CLI-Typer-blueviolet)

![Rich](https://img.shields.io/badge/UI-Rich-orange)

![Questionary](https://img.shields.io/badge/Menu-Questionary-red)

</p>
<p align="center">
<img src="assets/logo.png">
</p>
## 📦 Installation

```bash
pip install namgpt
```
## 🚀 Quick Start

```bash
namgpt --help
```

```bash
namgpt khoi-dong
```

```bash
namgpt chon
```
## ✨ Features

- Beautiful CLI
- Rich Panels
- Progress Bars
- Spinners
- Interactive Menus
- JSON Storage
- Calculator
- BMI Calculator
- Random Generator
## 📷 Screenshot

<p align="center">
<img src="assets/screenshot.png">
</p>
## 📁 Project Structure

```
namgpt
│
├── main.py
├── pyproject.toml
├── README.md
├── LICENSE
└── assets
    ├── logo.png
    ├── banner.png
    └── screenshot.png
```
## 👨‍💻 Author

Nguyen Nhat Nam

Made with ❤️ using Python